//
//  DBError.m
//  DropboxSDK
//
//  Created by Brian Smith on 7/21/10.
//  Copyright 2010 Dropbox, Inc. All rights reserved.
//

#import "DBError.h"

NSString* DBErrorDomain = @"dropbox.com";
